package com.exch.rate.ExchangeRateApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExchangeRateAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExchangeRateAppApplication.class, args);
	}

}
