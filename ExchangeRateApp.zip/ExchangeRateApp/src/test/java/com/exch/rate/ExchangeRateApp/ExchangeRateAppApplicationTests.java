package com.exch.rate.ExchangeRateApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExchangeRateAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
